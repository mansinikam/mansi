/**
 * Custom class file.
 * 
 * @author 'true' 12805
 * 
 * @version 'true' 1.0
 *
 */
package com.ptc.windchill.uwgm.proesrv.c11n;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import wt.change2.WTVariance;
import wt.epm.EPMDocument;
import wt.fc.QueryResult;
import wt.util.WTException;

import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.windchill.enterprise.change2.commands.RelatedChangesQueryCommands;

/**
 * @author 12805
 *
 */
public class CustomFFLModeledAttributesDelegate implements ModeledAttributesDelegate {

	/**
	 * Subtype variable.
	 */
	private static String SUBTYPE = "com.fgi_intranet.ALERT";

	private static HashMap ModeledAttrList = new HashMap();

	private static String alertName = "WT_ALERT_NAME";

	static
	/*     */{
		/* 57 */ModeledAttrList.put(alertName, String.class);
	}

	public HashMap getAvailableAttributes()
	/*     */{
		/* 79 */return ModeledAttrList;
		/*     */}

	public HashMap getModeledAttributes(Collection paramCollection)
	/*     */throws WTException
	/*     */{
		System.out.println("Inside GetModeledAttribtue !");
		/* 86 */HashMap localHashMap1 = new HashMap();
		/* 87 */for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext();)
		/*     */{
			/* 89 */HashMap localHashMap2 = new HashMap();
			/* 90 */EPMDocument localEPMDocument = (EPMDocument) localIterator.next();
			System.out.println("Fetching all alerts :: ");
			/* 91 */localHashMap2.put(alertName, getAllAlerts(localEPMDocument));
			/* 193 */localHashMap1.put(localEPMDocument, localHashMap2);
		}
		return localHashMap1;
	}

	private final String COMMA = ",";

	/**
	 * @param localEPMDocument
	 * @return
	 */
	private String getAllAlerts(EPMDocument doc) throws WTException {
		// TODO Auto-generated method stub
		System.out.println("Kd Says we are here !!!");
		StringBuffer sbf = new StringBuffer();
		QueryResult res = RelatedChangesQueryCommands.getRelatedProblemReports(doc);
		while (res.hasMoreElements()) {
			Object obj = res.nextElement();
			if (obj != null && (obj instanceof WTVariance)
					&& (TypeIdentifierHelper.getType(obj).toString().contains(SUBTYPE))) {
				WTVariance vary = (WTVariance) obj;
				String name = vary.getName();
				System.out.println("Alert Name : " + name);
				sbf.append(vary.getName()).append(COMMA);
			}
		}
		String toReturnAllName = sbf.toString();

		if (toReturnAllName.endsWith(COMMA)) {
			toReturnAllName  = toReturnAllName.substring(0, toReturnAllName.lastIndexOf(COMMA));
		}

		return toReturnAllName;
	}

	public CustomFFLModeledAttributesDelegate() {
	}
}
