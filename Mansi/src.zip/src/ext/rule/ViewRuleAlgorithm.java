package ext.rule;

import org.apache.log4j.Logger;

import wt.fc.ObjectReference;
import wt.fc.ReferenceFactory;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.rule.algorithm.RuleAlgorithm;
import wt.util.WTException;
import wt.vc.views.View;

import com.ptc.core.meta.common.impl.WCTypeInstanceIdentifier;

/**
 * Returns a LifeCycle name based on View name.
 * 
 * @version 'true' 1.0
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 **/
public final class ViewRuleAlgorithm implements RuleAlgorithm {
	/**
	 * Private variable for logger.
	 */
	private static final Logger LOG = LogR.getLogger(ViewRuleAlgorithm.class
			.getName());

	public Object calculate(Object[] args, WTContainerRef container)
			throws WTException {
		String lcName = null;
		/*
		 * If you are creating object using "Export from Spreadsheet" then the
		 * OIR will be invoked but the value of view.id will be null or if user
		 * didn't select any view
		 */
		if (args[0] == null) {
			lcName = "Basic";
		}
		try {
			if (args[0] instanceof WCTypeInstanceIdentifier) {
				final WCTypeInstanceIdentifier wct = (WCTypeInstanceIdentifier) args[0];
				final View view = (View) ((ObjectReference) new ReferenceFactory()
						.getReference(wct.getPersistenceIdentifier()))
						.getObject();
				
				/*ReferenceFactory refFac = new ReferenceFactory();
				ObjectReference ref =   (ObjectReference) refFac.getReference(wct.getPersistenceIdentifier());
				View view1 = (View) ref.getObject();*/
				
				
				// If the view name is design then select basic life cycle
				if (view.getName().toLowerCase().contains("design")) {
					LOG.debug("Inside if Design");
					lcName = "Basic";
				}
				/*
				 * If the view name is Manufacturing then select Approval
				 * lifecycle
				 */
				else if (view.getName().toLowerCase().contains("manufacturing")) {
					LOG.debug("Inside if Erection");
					lcName = "Approval";
				}
			}
		} catch (WTException e) {
			LOG.error(e);
			e.printStackTrace();
		}
		LOG.debug("lifecycle name " + lcName);
		/*
		 * At first when the OIR is getting called even before the user select
		 * Type from Type Picker the lcName will be null. But if you return null
		 * then it will throw NullPointerException.
		 */
		if (lcName == null) {
			return "Basic";
		}
		return lcName;
	}
}
