package ext.rule;
import java.util.Calendar;
import org.apache.log4j.Logger;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.rule.algorithm.RuleAlgorithm;
import wt.util.WTException;
/**
 * This Custom Rule Algorithm will return the current year. Ex. If the year is
 * 2014 it will return 14.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 * 
 */
public class YearRuleAlgorithm implements RuleAlgorithm {
	/**
	 * Private variable for logger.
	 */
	private static final Logger LOG = LogR.getLogger(YearRuleAlgorithm.class
			.getName());
	/**
	 * Rule algorithm.
	 * 
	 * @param arg0
	 *            The Object array where user's input will be stored if any
	 * @param arg1
	 *            The WTContainerReference in which the WTObject will go.
	 * @return Return the current year in String format
	 * @exception WTException
	 *             throw WTException
	 */
	@Override
	public Object calculate(Object[] userGivenName, WTContainerRef cont) throws WTException {
		final int index = 0;
		final int indexToTruncate = 2;
		final int year = Calendar.getInstance().get(Calendar.YEAR);
		/*
		 * Getting the current year and after converting it into
		 * String returning only the last two digit
		 */
		LOG.debug("The year is :- " + year);
		return String.valueOf(year).substring(indexToTruncate) + userGivenName[index].toString();
	}
}// Like this one can append month also 

