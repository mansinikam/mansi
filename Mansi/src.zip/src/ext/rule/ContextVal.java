package ext.rule;

import wt.inf.container.WTContainerRef;
import wt.rule.algorithm.RuleAlgorithm;
import wt.util.WTException;

/**
 * Custom rule algorithm class.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 * 
 */
public class ContextVal implements RuleAlgorithm {
	/*
	 * (non-Javadoc)
	 * 
	 * @see wt.rule.algorithm.RuleAlgorithm#calculate(java.lang.Object[],
	 * wt.inf.container.WTContainerRef)
	 */
	@Override
	public Object calculate(Object[] userInputs, WTContainerRef contRef)
			throws WTException {
		final int index = 0;
		/*
		 * Fetching container name.
		 */
		final String cont = contRef.getReferencedContainer().getName();
		final String value = userInputs[index].toString();
		/*
		 * Appending container name before the name given by the user.
		 */
		return (Object) (cont + value);
	}
}
