package ext;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import wt.fc.ObjectVector;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.httpgw.URLFactory;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.config.ConfigHelper;
import wt.vc.struct.IteratedUsageLink;
import wt.vc.struct.StructHelper;

import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.netmarkets.util.misc.NmActionServiceHelper;
import com.ptc.windchill.enterprise.object.WhereUsedConfigSpec;

//ext.AdvancedQuerySpecTest.checkTest
/**
 * Method used to read global enumeration value from Sub-Type and IBA.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
public final class AdvancedQuerySpecTest implements RemoteAccess {

	public static final String STATE = "RELEASED";

	public static final String DOCSUBTYPE = "wt.doc.WTDocument";

	public static void main(String[] args) throws WTPropertyVetoException, WTException {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");

		/*try {
			rms.invoke("readReleasedDateValue", AdvancedQuerySpecTest.class.getName(), null, new Class[] {},
					new Object[] {});
		} catch (RemoteException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		readReleasedDateValue();
	}

	public static void readReleasedDateValue() throws WTException  {
		WTPart part = getWTPart("GC000030");
		
		QueryResult localQueryResult = StructHelper.service.navigateUsedBy(part.getMaster(), IteratedUsageLink.class, true, true);
		System.out.println(localQueryResult.size());
		
		localQueryResult = filterOutNonLatestVersions(localQueryResult);
		System.out.println(localQueryResult.size());
		
		
		while(localQueryResult.hasMoreElements()){
			Object obj = localQueryResult.nextElement();
			System.out.println(obj.getClass());
			if(obj instanceof WTPart){
				WTPart parentPart = (WTPart) obj;
				String str1 = parentPart.getVersionInfo().getIdentifier().getValue();//for revision 
				String str2 = parentPart.getIterationIdentifier().getValue();//for iteration

				System.out.println("Number " + parentPart.getNumber() + "    " + str1 + "   " + str2);
				System.out.println(getInfoPageURL(parentPart));
			}
		}
	}
	
	public static QueryResult filterOutNonLatestVersions(QueryResult paramQueryResult) throws WTException {
		Object localObject = null;
		
		/* 458 */     ObjectVector localObjectVector1 = new ObjectVector();
		/* 459 */     Set localHashSet = new HashSet();
		/* 460 */     while (paramQueryResult.hasMoreElements()) {
		/* 461 */       localObject = (Iterated)paramQueryResult.nextElement();
		/* 462 */       localObjectVector1.addElement(((Iterated)localObject).getMaster());
		/* 463 */       localHashSet.add(Long.valueOf(((Iterated)localObject).getBranchIdentifier()));
		/*     */     }
		/*     */     
		/* 466 */     localObject = ConfigHelper.service.filteredIterationsOf(new QueryResult(localObjectVector1), new WhereUsedConfigSpec());
		/*     */     
		/*     */ 
		/* 469 */     ObjectVector localObjectVector2 = new ObjectVector();
		/* 470 */     while (((QueryResult)localObject).hasMoreElements()) {
		/* 471 */       Iterated localIterated = (Iterated)((QueryResult)localObject).nextElement();
		/* 472 */       if (localHashSet.contains(Long.valueOf(localIterated.getBranchIdentifier()))) {
		/* 473 */         localObjectVector2.addElement(localIterated);
		/*     */       }
		/*     */     }
		/*     */     
		/* 477 */     return new QueryResult(localObjectVector2);
		/*     */   }
	
	public static String getInfoPageURL(Persistable persist) throws WTException
	{
		LOG.debug("Inside Link Making");
		if (persist == null)
		{
			throw new WTException("No persistable object !!");
		}
		NmAction localNmAction = NmActionServiceHelper.service.getAction("object", "view");
		HashMap localHashMap = new HashMap();
		/*
		 * Generating URL. This method is being called from JSP.
		 */
		localHashMap.put("oid", new ReferenceFactory().getReferenceString(persist));
		String str = (new URLFactory()).getHREF(((String) localNmAction.getUrl()), localHashMap, true);
		LOG.debug("The link created " + str);
		return str;
	}
	
	/**
	 * @throws WTPropertyVetoException
	 * @throws WTException
	 * 
	 *//*
	public static void readReleasedDateValue() throws WTPropertyVetoException, WTException {
		// TODO Auto-generated method stub

		boolean flagAccess = SessionServerHelper.manager.isAccessEnforced();
		SessionServerHelper.manager.setAccessEnforced(false);

		QuerySpec subSelect = new QuerySpec();

		
		int bwtdoc = subSelect.appendClassList(WTDocument.class, false);
		int bwtdocMaster = subSelect.appendClassList(WTDocumentMaster.class, false);

		ClassAttribute subBranchIditerationInfo = new ClassAttribute(WTDocument.class, "iterationInfo.branchId");
		SQLFunction maxFunction = SQLFunction.newSQLFunction(SQLFunction.MAXIMUM, subBranchIditerationInfo);
		subSelect.appendSelect(maxFunction, new int[] { bwtdoc }, false);
		subSelect.appendWhere(new SearchCondition(WTDocument.class, "masterReference.key.id", WTDocumentMaster.class,
				"thePersistInfo.theObjectIdentifier.id"), new int[] { bwtdoc, bwtdocMaster });
		subSelect.appendGroupBy(new ClassAttribute(WTDocumentMaster.class, WTDocumentMaster.NUMBER),
				new int[] { bwtdocMaster }, false);
		subSelect.setAdvancedQueryEnabled(true);

		QuerySpec mainSpec = new QuerySpec();

		int wtdoc = mainSpec.addClassList(WTDocument.class, true);
		int objHistory = mainSpec.addClassList(ObjectHistory.class, false);
		int lcHistory = mainSpec.addClassList(LifeCycleHistory.class, false);
		int typeIndex = mainSpec.appendClassList(WTTypeDefinition.class, false);

		mainSpec.appendSelect(new ClassAttribute(LifeCycleHistory.class, "thePersistInfo.modifyStamp"),
				new int[] { lcHistory }, false);

		mainSpec.appendWhere(new SearchCondition(WTDocument.class, WTDocument.LIFE_CYCLE_STATE, SearchCondition.EQUAL,
				STATE), new int[] { wtdoc });
		mainSpec.appendAnd();

		final SearchCondition sctype = new SearchCondition(WTDocument.class, "typeDefinitionReference.key.id",
				WTTypeDefinition.class, "thePersistInfo.theObjectIdentifier.id");

		mainSpec.appendWhere(sctype, new int[] { wtdoc, typeIndex });
		mainSpec.appendAnd();

		final SearchCondition joinObjectHistoryWtDoc = new SearchCondition(ObjectHistory.class,
				"roleAObjectRef.key.id", WTDocument.class, "thePersistInfo.theObjectIdentifier.id");

		mainSpec.appendWhere(joinObjectHistoryWtDoc, new int[] { objHistory, wtdoc });
		mainSpec.appendAnd();

		final SearchCondition joinObjectHistoryLcHistory = new SearchCondition(ObjectHistory.class,
				"roleBObjectRef.key.id", LifeCycleHistory.class, "thePersistInfo.theObjectIdentifier.id");

		mainSpec.appendWhere(joinObjectHistoryLcHistory, new int[] { objHistory, lcHistory });
		mainSpec.appendAnd();

		mainSpec.appendWhere(new SearchCondition(LifeCycleHistory.class, LifeCycleHistory.ACTION,
				SearchCondition.EQUAL, "Enter_Phase"), new int[] { lcHistory });
		mainSpec.appendAnd();

		mainSpec.appendWhere(new SearchCondition(LifeCycleHistory.class, LifeCycleHistory.STATE, SearchCondition.EQUAL,
				STATE), new int[] { lcHistory });
		mainSpec.appendAnd();

		mainSpec.appendWhere(
				new SearchCondition(WTDocument.class, WTDocument.LATEST_ITERATION, SearchCondition.IS_TRUE),
				new int[] { wtdoc });
		mainSpec.appendAnd();

		SearchCondition scSWPart = new SearchCondition(WTTypeDefinition.class, "logicalIdentifier",
				SearchCondition.LIKE, "%" + DOCSUBTYPE + "%", true);
		mainSpec.appendWhere(scSWPart, new int[] { typeIndex });
		mainSpec.appendAnd();

		mainSpec.appendWhere(new SearchCondition(subBranchIditerationInfo, SearchCondition.IN, new SubSelectExpression(
				subSelect)), new int[] { wtdoc });
		mainSpec.setAdvancedQueryEnabled(true);

		final QueryResult result = PersistenceServerHelper.manager.query(mainSpec);

		System.out.println("Result Size : " + result.size());

		while (result.hasMoreElements()) {

			Object[] objs = (Object[]) result.nextElement();

			WTDocument doc = (WTDocument) objs[wtdoc];
			WrappedTimestamp stamp = (WrappedTimestamp) objs[1];
			System.out.println("The document number : " + doc);
			System.out.println("The Release Date : " + stamp);
			LOG.debug("Use logger in your actual code instead of sys out");
		}

		SessionServerHelper.manager.setAccessEnforced(flagAccess);
	}*/

	/**
	 * @param string
	 * @return
	 * @throws WTException 
	 */
	private static WTPart getWTPart(String number) throws WTException {
		QuerySpec qs = new QuerySpec(WTPart.class); 
		
		WTPart pt  = null;

		qs.appendWhere(new SearchCondition(WTPart.class,WTPart.NUMBER,SearchCondition.EQUAL,number),new int[] { 0 });

		QueryResult qr = PersistenceHelper.manager.find((StatementSpec)qs); while(qr.hasMoreElements())
		{

			pt = (WTPart)qr.nextElement();

		}

		return pt;
	}

	/**
	 * Private variable for Logger.
	 */
	private static final org.apache.log4j.Logger LOG = LogR.getLogger(AdvancedQuerySpecTest.class.getName());

}
