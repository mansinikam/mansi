package ext.customization.listener;

import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.inf.container.WTContainerServiceEvent;
import wt.projmgmt.admin.Project2;
import wt.services.Manager;
import wt.services.ManagerException;
import wt.services.ManagerService;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class CreateProjectListenerService extends StandardManager implements
		CreateProjectListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8980193532760592607L;

	private static final String CLASSNAME = CreateProjectListenerService.class
			.getName();

	public static CreateProjectListenerService newCreateProjectListenerService()
			throws WTException {
		CreateProjectListenerService instance = new CreateProjectListenerService();
		instance.initialize();
		return instance;
	}

	@Override
	public String getName() {
		return CLASSNAME;
	}

	@Override
	public String getStartupType() {
		return Manager.STARTUP_AUTOMATIC;
	}

	protected synchronized void performStartupProcess() throws ManagerException {

		getManagerService().addEventListener(
				new ServiceEventListenerAdapter(CLASSNAME) {
					public void notifyVetoableEvent(Object event)
							throws WTException {
						try {
							listenForProjectCreate(event);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				},
				WTContainerServiceEvent
						.generateEventKey(WTContainerServiceEvent.POST_CREATE));
	}

	@Override
	public void registerEvents(ManagerService manager) {
		manager.addEventBranch(WTContainerServiceEvent
				.generateEventKey(WTContainerServiceEvent.POST_CREATE),
				WTContainerServiceEvent.class.getName(),
				WTContainerServiceEvent.POST_CREATE);
	}

	@Override
	public void listenForProjectCreate(Object event) throws WTException {
		WTContainerServiceEvent eventObj = (WTContainerServiceEvent) event;

		// Using this class you can create a Listener for creation of
		// WTContainer(Project2 , PDMLinkProduct etc.)
		if (eventObj.getTarget() instanceof Project2)

		/*
		 * If you want to create a listener for PDMLinkProduct then change
		 * Project2 in PDMLinkProduct in above line
		 */
		{
			Project2 proj = (Project2) eventObj.getTarget();

			try {

				WTDocument doc = WTDocument.newWTDocument();
				doc.setContainer(proj);
				String name = proj.getName();
				doc.setName(name);
				String no = proj.getProjectNumber();
				doc.setNumber(no);
				PersistenceHelper.manager.store(doc);

			} catch (ClassCastException e) {
				System.out.println("class cast exception");
			} catch (WTPropertyVetoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
}// class end
