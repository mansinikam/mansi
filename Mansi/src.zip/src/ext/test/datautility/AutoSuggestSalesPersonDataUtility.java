package ext.test.datautility;

import org.apache.log4j.Logger;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AbstractAttributeDataUtility;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.rendering.guicomponents.SuggestTextBox;
import com.ptc.core.meta.type.common.impl.DefaultTypeInstance;



//ext.test.datautility.AutoSuggestSalesPersonDataUtility
public class AutoSuggestSalesPersonDataUtility extends AbstractAttributeDataUtility 
{
	
	private static final String CLASSNAME = AutoSuggestSalesPersonDataUtility.class
			.getName();
	public static Logger logger = Logger.getLogger(CLASSNAME);

	
	
		@Override
		public Object getDataValue(final String compId, final Object datum, final ModelContext modelContext) throws WTException {
			System.out.println("inside SpecificationSuggestionDataUtility ");
			Object object = super.getDataValue(compId, datum, modelContext);
			//final ComponentMode mode=modelContext.getDescriptorMode();
			
				
				System.out.println("Inside if ");
				
				final SuggestTextBox sugTxtBox = new SuggestTextBox(compId, "suggestsalesperson");
				sugTxtBox.setColumnName(AttributeDataUtilityHelper.getColumnName(compId, datum, modelContext));
			
				
				sugTxtBox.setWidth(25);
				sugTxtBox.setMinChars(3);
				sugTxtBox.setFrequency(1500);
				sugTxtBox.setMaxResults(15);
				final Object value = ((DefaultTypeInstance) datum).getAttributeContainer().get(modelContext.getATI());
				
				System.out.println("Value is " + value);
				
				if(value!=null){
					sugTxtBox.setValue(value.toString());
				}
				object=sugTxtBox;
			
				
			return object;
		}

}
