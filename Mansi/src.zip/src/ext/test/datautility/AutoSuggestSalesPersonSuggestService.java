/**
 * Custom class file.
 * 
 * @author 'true' 12805
 * 
 * @version 'true' 1.0
 *
 */
package ext.test.datautility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.org.WTUser;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

import com.ptc.core.components.suggest.SuggestParms;
import com.ptc.core.components.suggest.SuggestResult;
import com.ptc.core.components.suggest.Suggestable;

/**
 * @author 12805
 *
 */
//ext.test.datautility.AutoSuggestSalesPersonSuggestService
public class AutoSuggestSalesPersonSuggestService implements Suggestable{

	/**
	 * Private variable for Logger.
	 */
	private static final org.apache.log4j.Logger LOG = wt.log4j.LogR
			.getLogger(AutoSuggestSalesPersonSuggestService.class.getName());
	
	/**
	 * @param paramSuggestParms
	 * @return
	 */
	@Override
	public Collection<SuggestResult> getSuggestions(SuggestParms paramSuggestParms) {
		List<SuggestResult> suggestionResult = new ArrayList<SuggestResult>();
		String name = paramSuggestParms.getSearchTerm();
		
		suggestionResult.addAll(getPrincipal(name));
		
		return suggestionResult;
	}
	
	private static List<SuggestResult> getPrincipal(String userName) {
		List<SuggestResult> used = new ArrayList<SuggestResult>();
		WTUser user = null;
		System.out.println("User to find : " + userName);
		QuerySpec userSpec;
		try {
			userSpec = new QuerySpec(WTUser.class);
			userSpec.appendWhere(new SearchCondition(WTUser.class, WTUser.NAME, SearchCondition.LIKE, "%"+userName+"%"),
					new int[] { 0 });
			QueryResult result = PersistenceServerHelper.manager.query((StatementSpec) userSpec);
			System.out.println("Result Size : " + result.size());
			while (result.hasMoreElements()) {
				user = (WTUser) result.nextElement();
				System.out.println("User found : " + user.getFullName() );
				used.add(SuggestResult.valueOf(user.getFullName()));
			}
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return used;
	}
	

}
