package ext.test.datautility;

import wt.fc.QueryResult;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.folder.SubFolderReference;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.windchill.enterprise.folder.dataUtilities.FolderNameDataUtility;

public class FolderedDataUtility extends FolderNameDataUtility {
	@Override
	public Object getDataValue(String paramString, Object datum,
			ModelContext paramModelContext) throws WTException {
		Object obj = super.getDataValue(paramString, datum,
				paramModelContext);
		SubFolderReference sub = null;
		if (datum instanceof SubFolderReference) {
			sub = (SubFolderReference) datum;
		}
		if (sub != null) {
			if (sub.getObject() instanceof SubFolder) {
				QueryResult result = FolderHelper.service
						.findFolderContents((SubFolder) sub.getObject());
				if (result.size() == 0) {
					GUIComponentArray gui = (GUIComponentArray) obj;
					GUIComponentArray newGui = new GUIComponentArray();
					for (int i = 0; i < gui.size(); i++) {
						GuiComponent guiComp = gui.get(i);
						if (guiComp instanceof IconComponent) {
							IconComponent ico = new IconComponent(
									"netmarkets/images/folder_content.gif");
							newGui.addGUIComponent(ico);
						} else {
							newGui.addGUIComponent(guiComp);
						}
					}
					return newGui;
				}
			}
		}
		return obj;
	}
}
