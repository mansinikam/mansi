package ext.test.processor;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.ReferenceFactory;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewReference;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;

/**
 * Processor class for custom wizard.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 * 
 */
public class SelectedObjectFormProcessor extends DefaultObjectFormProcessor {

	/**
	 * Overridden method of {@link DefaultObjectFormProcessor}.
	 * 
	 * @param commandBean
	 *            the {@link NmCommandBean} object
	 * 
	 * @param list
	 *            list's of {@link ObjectBean}
	 * 
	 * @exception WTException
	 *                throws {@link WTException}
	 * 
	 * @return object of {@link FormResult}
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public FormResult doOperation(NmCommandBean commandBean,
			List<ObjectBean> list) throws WTException {
		
		/*
		 * Fetch the data given by the user. If you know the exact parameter
		 * name then you may use this method
		 */
		HttpServletRequest request = commandBean.getRequest();
		String type = request.getParameter("Type");

		/*
		 * This is another method to fetch user input
		 */

		HashMap map = commandBean.getText();
		Object[] keys = map.keySet().toArray();
		String name = null;
		String number = null;
		String containerOid = null;
		String folderOid = null;
		String desCripTion = null;
		String viewName = null;

		if (type.toLowerCase().contains("wtpart")) {

			name = ((String) map.get("namep")).toUpperCase();
			number = ((String) map.get("numberp")).toUpperCase();
			folderOid = ((String) map.get("loc_folderp"));
			containerOid = ((String) map.get("loc_containerp"));
			viewName = ((String) map.get("view"));
		} else {
			name = ((String) map.get("name")).toUpperCase();
			number = ((String) map.get("number")).toUpperCase();
			folderOid = ((String) map.get("loc_folder"));
			containerOid = ((String) map.get("loc_container"));
		}

		/* To extract textArea's value there are two methods */
		/* ***********************1************************* */
		/*
		 * Enumeration enumer = request.getParameterNames(); while
		 * (enumer.hasMoreElements()) { String nameObj =
		 * enumer.nextElement().toString(); if (nameObj.contains("description")
		 * && !(nameObj.endsWith("old"))) { desCripTion =
		 * request.getParameter(nameObj); } }
		 */
		/* ***********************2************************* */
		HashMap mapArea = commandBean.getTextArea();
		desCripTion = ((String) mapArea.get("description"));

		Persistable per = null;
		if (type.toLowerCase().contains("part")) {
			per = createPart(name, number, containerOid, folderOid, viewName);
		} else if (type.toLowerCase().contains("document")) {
			per = createDocument(name, number, desCripTion, containerOid,
					folderOid);
			try {
				((WTDocument)per).setDescription("UPDATED FROM METHOD");
				System.out.println("after persisting the value");
				PersistenceServerHelper.manager.update(per);
				PersistenceHelper.manager.refresh(per);
			} catch (WTPropertyVetoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		ObjectBean ob = ObjectBean.newInstance();
		ob.setObject(per);
		list.add(ob);

		/* Adding the Persistable object in the List */
		return super.doOperation(commandBean, list);
	}

	/*
	 * <--- Short note about inline message --> You can develop inline message
	 * to capture success or failure of certain user actions. You can also use
	 * this to display warning or any informational message. However, this
	 * cannot be used for any kind of message that requires user input.
	 * 
	 * In our wizard the inline message is like Confirmation: Create Successful
	 * followed by the Persistable object's name as hyperlink along with the
	 * appropriate icon
	 */

	/**
	 * Overridden method of {@link DefaultObjectFormProcessor}. Used for inline
	 * messaging.
	 * 
	 * @return {@link WTMessage}
	 */
	public WTMessage getSuccessMessageTitle() {
		return new WTMessage("com.ptc.core.ui.successMessagesRB",
				"OBJECT_CREATE_SUCCESSFUL_TITLE", (Object[]) null);
	}

	/**
	 * Method used to create WTDocument as per the user input.
	 * 
	 * @param name
	 *            name of the {@link WTDocument} given by the user
	 * 
	 * @param number
	 *            of the {@link WTDocument} given by the user
	 * 
	 * @param desCripTion
	 *            description given by the user
	 * 
	 * @param containerOid
	 *            OID of {@link WTContainer} given by the user
	 * 
	 * @param folderOid
	 *            OID of the {@link Folder} select by the user
	 * 
	 * @return the object of {@link Persistable}
	 * 
	 * @throws WTException
	 *             throws {@link WTException}
	 */
	private Persistable createDocument(String name, String number,
			String desCripTion, String containerOid, String folderOid)
			throws WTException {
		WTDocument doc = WTDocument.newWTDocument();
		try {
			/*
			 * Setting the name and number of the WTDocument as per the user
			 * input
			 */
			doc.setName(name);
			doc.setNumber(number);
			if (desCripTion != null) {
				doc.setDescription(desCripTion); // method to set description
			}
			doc.setContainer((WTContainer) fromReferenceToObject(containerOid));
			/* Setting the container as well as folder as selected by the user */
			assignFolder(doc, folderOid);
			/* Storing the WTDocument in DB */
			doc = (WTDocument) PersistenceHelper.manager.save(doc);
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		 * Returning the WTDocument object. As WTDocument implements Persistable
		 * so we can use Persistable's object to hold the data.
		 */
		return doc;
	}

	/**
	 * Create {@link WTPart} as per the input given by the user.
	 * 
	 * @param name
	 *            name of the {@link WTPart}
	 * 
	 * @param number
	 *            number of the {@link WTPart}
	 * 
	 * @param containerOid
	 *            OID of the {@link WTContainer} select by the user
	 * 
	 * @param folderOid
	 *            OID of the {@link Folder} given by the user
	 * 
	 * @param viewName
	 *            the name of the View
	 * 
	 * @return {@link Persistable} object
	 * 
	 * @throws WTException
	 *             throws {@link WTException}
	 */
	private Persistable createPart(String name, String number,
			String containerOid, String folderOid, String viewName)
			throws WTException {
		WTPart part = WTPart.newWTPart();
		try {
			part.setName(name);
			part.setNumber(number);
			part.setContainer((WTContainer) fromReferenceToObject(containerOid));
			assignFolder(part, folderOid);
			part.setView(ViewReference.newViewReference(ViewHelper.service
					.getView(viewName)));
			/*
			 * Storing the WTPart after creating and assigning different
			 * attribute's value as per user input
			 */
			part = (WTPart) PersistenceHelper.manager.save(part);
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return part;
	}

	/**
	 * Return the object from the given object reference.
	 * 
	 * @param objectReference
	 *            The object reference
	 * 
	 * @return The persistable object from the given reference
	 * 
	 * @exception WTException
	 *                throws {@link WTException}
	 */
	private Persistable fromReferenceToObject(String objectReference)
			throws WTException {
		final ReferenceFactory factory = new ReferenceFactory();
		final ObjectReference objRef = (ObjectReference) factory
				.getReference(objectReference);
		return (objRef.getObject());
	}

	/**
	 * Assign the given object to the given folder.
	 * 
	 * @param folderEntry
	 *            The object which need to be assigned typically WTPart or
	 *            WTDocument
	 * 
	 * @param folderOid
	 *            The folder's object id in which the object will be assigned
	 * 
	 * @exception WTException
	 *                throws {@link WTException}
	 */
	private void assignFolder(FolderEntry folderEntry, String folderOid)
			throws WTException {
		/*
		 * Fetching the Folder object from the given folder object id
		 */
		final Folder folder = ((Folder) fromReferenceToObject(folderOid));
		FolderHelper.assignLocation(folderEntry, folder);
	}
}
