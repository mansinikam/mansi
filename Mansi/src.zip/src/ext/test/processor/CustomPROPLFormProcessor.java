package ext.test.processor;

import java.io.FileInputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import wt.fc.PersistenceHelper;
import wt.log4j.LogR;
import wt.pds.StatementSpec;
import wt.pom.POMInitException;
import wt.pom.PersistenceException;
import wt.pom.PersistentObjectManager;
import wt.preference.PreferenceHelper;
import wt.projmgmt.admin.Project2;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.version.WindchillVersion;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.project.processor.CreatePROPLProjectFormProcessor;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.instassm.ReleaseIdException;

//ext.test.processor.CustomPROPLFormProcessor
/**
 * Custom Processor for create Project.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 */
public class CustomPROPLFormProcessor extends CreatePROPLProjectFormProcessor {

	/**
	 * Private variable for Logger.
	 */
	private static final Logger LOG = LogR
			.getLogger(CustomPROPLFormProcessor.class.getName());

	/**
	 * Do operation of {@link CustomPROPLFormProcessor}.
	 * 
	 * @param arg0
	 *            NmCommandBean
	 * 
	 * @param paramList
	 *            list of ObjectBean
	 * 
	 * @throws WTException
	 *             throws {@link WTException}.
	 * 
	 * @return corresponding {@link FormResult}.
	 */
	@Override
	public FormResult doOperation(NmCommandBean arg0, List<ObjectBean> paramList)
			throws WTException {
		// FormResult result =
		Project2 localProject = null;
		ObjectBean objBean = null;
		/*
		 * Fetching the Project2 from List given.
		 */
		for (Iterator<ObjectBean> localIterator = paramList.iterator(); localIterator
				.hasNext();) {
			objBean = localIterator.next();
			localProject = (Project2) (objBean.getObject());
		}
		LOG.debug("sub-type checking");
		if ((Boolean) PreferenceHelper.service.getValue(
				"ext/tgs/ProjectPreference", "WINDCHILL")) {
			/*
			 * If the Project is of a specific subtype then we need to find the
			 * count.
			 */

			// localTransaction.start();
			System.out.println("Before Renumbering");
			String number = String.valueOf(Integer
					.parseInt(getCurrentSequence()) + 1);
			/*
			 * Setting the value of ProjectNumber.
			 */
			System.out.println(number);
			localProject.setProjectNumber(number);
			LOG.debug("After renumbering");
			/*
			 * //PersistenceHelper.manager.save(localProject);
			 * //localTransaction.commit();
			 * System.out.println("Inside processor"); //localTransaction =
			 * null;
			 */
		}
		/*
		 * Storing the object in ObjectBean.
		 */
		objBean.setObject(localProject);
		/*
		 * Removing all the parameter of the list.
		 */
		for (int loop = 0; loop < paramList.size(); loop++) {
			paramList.remove(loop);
		}
		/*
		 * Adding the obejct of Project2 in the List.
		 */
		paramList.add(objBean);
		/*
		 * List<ObjectBean> listToGive = new ArrayList<ObjectBean>(1);
		 * listToGive.add(objBean);
		 */
		/*
		 * calling the Super class method.
		 */
		return super.doOperation(arg0, paramList);
	}

	private String getCurrentSequence() throws POMInitException,
			ReleaseIdException, PersistenceException {
		if (WindchillVersion.getInstalledAssemblyDisplayLabelsAsString()
				.contains("10.1"))
			return getCurrentSequenceForTenOne();
		else
			return getCurrentSequenceForTenTwo();
	}

	private String getCurrentSequenceForTenOne() {
		final boolean isCreateAccess = SessionServerHelper.manager
				.isAccessEnforced();
		try {
			SessionServerHelper.manager.setAccessEnforced(false);
			return String.format(
					"%08d",
					PersistenceHelper.manager.find(
							(StatementSpec) new QuerySpec(Project2.class))
							.size());
		} catch (QueryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			SessionServerHelper.manager.setAccessEnforced(isCreateAccess);

		}
		return null;
	}

	private String getCurrentSequenceForTenTwo() throws POMInitException,
			PersistenceException {

		return String.format("%08d", Integer.parseInt(PersistentObjectManager
				.getPom().getCurrentSequence("project_seq")));
		/*
		 * This code only work // in 10.2. For lower version use the above code
		 */
	}
}
