package ext.test.builder;

import java.util.ArrayList;
import java.util.List;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;

public class TableBuilderHelper {
	
	private TableBuilderHelper() {
		// TODO Auto-generated constructor stub
	}
	
	public static List<Persistable> getObjectByProduct(
			@SuppressWarnings("rawtypes") Class className, String productName)
			throws WTException {
		final List<Persistable> listOfObject = new ArrayList<Persistable>();
		final QuerySpec queryspec = new QuerySpec(className);
		final int contIndex = queryspec.appendClassList(PDMLinkProduct.class,
				false);
		final SearchCondition sc1 = new SearchCondition(className,
				"containerReference.key.id", PDMLinkProduct.class,
				"thePersistInfo.theObjectIdentifier.id");

		queryspec.appendWhere(sc1, new int[] { 0, contIndex });
		queryspec.appendAnd();
		final SearchCondition scSWPart = new SearchCondition(
				PDMLinkProduct.class, "containerInfo.name",
				SearchCondition.EQUAL, productName, true);
		queryspec.appendWhere(scSWPart, new int[] { contIndex });
		final QueryResult result = PersistenceHelper.manager
				.find((StatementSpec) new LatestConfigSpec().appendSearchCriteria(queryspec));
		while (result.hasMoreElements()) {
			Object obj = result.nextElement();
			if (obj instanceof Persistable[]) {
				Persistable[] per = (Persistable[]) obj;
				for (Persistable persist : per) {
					listOfObject.add(persist);
				}
			}
		}
		return listOfObject;
	}
}
