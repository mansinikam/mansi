package ext.test.builder;

import java.util.List;

import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.AbstractComponentDataBuilder;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.netmarkets.util.beans.NmCommandBean;

@ComponentBuilder(value = "custom.table", type = ComponentBuilderType.DATA_ONLY)
public class PartAndCADDocumentBuilder extends AbstractComponentDataBuilder {

	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
			throws WTException {
		final NmCommandBean localNmCommandBean = ((JcaComponentParams) arg1)
				.getHelperBean().getNmCommandBean();
		final String productName = localNmCommandBean.getContainer().getName();

		final List<Persistable> listOfObject = TableBuilderHelper.getObjectByProduct(WTPart.class,
				productName);
		listOfObject.addAll(TableBuilderHelper.getObjectByProduct(EPMDocument.class, productName));
		return listOfObject;
	}

	
} //In this example the component id is custom.table

