/**
 * 
 */
package ext.test.builder;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.CREATED;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.CREATED_BY;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.ICON;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.INFO_ACTION;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.LAST_MODIFIED;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NAME;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.OWNER;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.STATE;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.VERSION;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.core.htmlcomp.components.JCAConfigurableTable;
import com.ptc.core.htmlcomp.createtableview.Attribute;
import com.ptc.core.htmlcomp.tableview.SortColumnDescriptor;
import com.ptc.core.htmlcomp.tableview.TableColumnDefinition;
import com.ptc.core.htmlcomp.tableview.TableViewDescriptor;

import ext.test.resource.ViewConfigurableTableResource;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */


	public class PartStructureListTreeViews extends JCAConfigurableTable
    {
		final String resourceName = ViewConfigurableTableResource.class
				.getName();

		/**
		 * @param paramLocale
		 * @return
		 */
		@Override 
		public String getLabel(Locale paramLocale) {
			System.out.println("Getting label ");
			// TODO Auto-generated method stub
			return "Views";
		}

		/**
		 * @param paramLocale
		 * @return
		 */
		@Override
		public List getSpecialTableColumnsAttrDefinition(Locale paramLocale) {
			System.out.println("calling special table column attr definition ::");
			 return Collections.singletonList(new Attribute.TextAttribute("endItem", "End Item", paramLocale));
		}

		/**
		 * @return
		 */
		@Override
		public Class[] getClassTypes() {
			System.out.println("Getting class type :: ");
			return new Class[] { WTPart.class,EPMDocument.class };
		}

		/**
		 * @param paramString
		 * @param paramLocale
		 * @return
		 * @throws WTException
		 */
		@Override
		public List getOOTBTableViews(String paramString, Locale paramLocale)
				throws WTException {
			System.out.println("Getting views :: ");
			List localArrayList = new ArrayList();

			Vector localVector1 = new Vector();
			

			createColumns(localVector1);
			addCommonViews(localArrayList,localVector1);

			return localArrayList;
		}

		/**
		 * @param paramArrayList
		 * @param paramVector1
		 * @param paramVector2
		 * @param paramVector3
		 */
		private void addCommonViews(List paramArrayList, Vector paramVector1) {
			String str1 = "";
			String str2 = "";
			try {
				List localArrayList = new ArrayList();
				SortColumnDescriptor localSortColumnDescriptor = new SortColumnDescriptor();
				localSortColumnDescriptor.setColumnId("name");
				localSortColumnDescriptor.setOrder("ASCENDING");
				localArrayList.add(localSortColumnDescriptor);

				final String tableId = "ext.test.builder.PartStructureBuilder";
				// TableViewDescriptor localTableViewDescriptor;
				str1 = getViewResourceEntryKey(resourceName, "DEFAULT");
				str2 = getViewResourceEntryKey(resourceName, "DEFAULT_DESC");
				TableViewDescriptor localTableViewDescriptor = TableViewDescriptor
						.newTableViewDescriptor(str1, tableId, true, true,
								paramVector1, null, true, str2);
				localTableViewDescriptor.setColumnSortOrder(localArrayList);
				paramArrayList.add(localTableViewDescriptor);
			} catch (WTPropertyVetoException localWTPropertyVetoException) {
				localWTPropertyVetoException.printStackTrace();
			} catch (WTException exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}

		}

		/**
		 * @param localVector1
		 * @param localVector2
		 * @param localVector3
		 * @throws WTException
		 */
		private void createColumns(Vector paramVector1) throws WTException {
			if (paramVector1.isEmpty()) {
				paramVector1.addAll(getCommonColumnList());
				paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
						CREATED, false));
				paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
						STATE, false));
			}
}

		/**
		 * @return
		 */
		@Override
		public String getOOTBActiveViewName() {
			System.out.println("Getting active view name");
			return getViewResourceEntryKey(
					resourceName, "DEFAULT");
		}

		/**
		 * @return
		 */
		@Override
		public String getDefaultSortColumn() {
			System.out.println("Getting default sort column :: ");
			// TODO Auto-generated method stub
			return LAST_MODIFIED;
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		private Vector<TableColumnDefinition> getCommonColumnList()
				throws WTException {
			Vector localVector = new Vector();
			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					ICON, false));
			
			localVector.add(TableColumnDefinition.newTableColumnDefinition(NAME,
					false));

			
			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					INFO_ACTION, false));

			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					VERSION, false));
			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					LAST_MODIFIED, false));
			return localVector;
		}

		@Override
		public boolean isColumnLocked(String paramString) {
			System.out.println("Geting locked column name ::");
			return ((paramString.equals("type_icon")) || (paramString
					.equals("name")));
		}

		@Override
		public boolean showChooseItemTypesStep() {
			System.out.println("Getting choose item type step ::");
			return true;
		}

		@Override
		public boolean showFilteringStep() {
			System.out.println("Getting choose filtering step ::");
			return true;
		}

		@Override
		public boolean showSortingStep() {
			System.out.println("Getting choose sorting step :: ");
			return true;
		}
    }
	

