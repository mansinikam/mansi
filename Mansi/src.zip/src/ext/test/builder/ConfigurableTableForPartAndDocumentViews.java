/**
 * 
 */
package ext.test.builder;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.core.htmlcomp.components.JCAConfigurableTable;
import com.ptc.core.htmlcomp.tableview.SortColumnDescriptor;
import com.ptc.core.htmlcomp.tableview.TableColumnDefinition;
import com.ptc.core.htmlcomp.tableview.TableViewDescriptor;

import ext.test.resource.ViewConfigurableTableResource;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
/*
 * Check ConfigurableTable API documentation for different information about the
 * methods.
 */
public class ConfigurableTableForPartAndDocumentViews extends
		JCAConfigurableTable {

	/**
	 * @param paramLocale
	 * @return
	 */
	@Override
	public String getLabel(Locale paramLocale) {
		// TODO Auto-generated method stub
		return "Persistable Object Table";
	}

	/**
	 * @param paramLocale
	 * @return
	 */
	@Override
	public List getSpecialTableColumnsAttrDefinition(Locale paramLocale) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 */
	@Override
	public Class[] getClassTypes() {
		return new Class[] { WTPart.class };
	}

	/**
	 * @param paramString
	 * @param paramLocale
	 * @return
	 * @throws WTException
	 */
	@Override
	public List getOOTBTableViews(String paramString, Locale paramLocale)
			throws WTException {
		List localArrayList = new ArrayList();

		Vector localVector1 = new Vector();
		Vector localVector2 = new Vector();
		Vector localVector3 = new Vector();

		createColumns(localVector1, localVector2, localVector3);
		addCommonViews(localArrayList, localVector1, localVector2, localVector3);

		return localArrayList;
	}

	/**
	 * @param paramArrayList
	 * @param paramVector1
	 * @param paramVector2
	 * @param paramVector3
	 */
	private void addCommonViews(List paramArrayList, Vector paramVector1,
			Vector paramVector2, Vector paramVector3) {
		String str1 = "";
		String str2 = "";
		try {
			List localArrayList = new ArrayList();
			SortColumnDescriptor localSortColumnDescriptor = new SortColumnDescriptor();
			localSortColumnDescriptor.setColumnId("name");
			localSortColumnDescriptor.setOrder("ASCENDING");
			localArrayList.add(localSortColumnDescriptor);

			final String resourceName = ViewConfigurableTableResource.class
					.getName();

			final String tableId = "ext.test.builder.CommonComponentConfigBuilder";
			// TableViewDescriptor localTableViewDescriptor;
			str1 = getViewResourceEntryKey(resourceName, "DEFAULT");
			str2 = getViewResourceEntryKey(resourceName, "DEFAULT_DESC");
			TableViewDescriptor localTableViewDescriptor = TableViewDescriptor
					.newTableViewDescriptor(str1, tableId, true, true,
							paramVector3, null, true, str2);
			localTableViewDescriptor.setColumnSortOrder(localArrayList);
			paramArrayList.add(localTableViewDescriptor);

			str1 = getViewResourceEntryKey(resourceName, "STATE");
			str2 = getViewResourceEntryKey(resourceName, "STATE_DESC");
			localTableViewDescriptor = TableViewDescriptor
					.newTableViewDescriptor(str1, tableId, true, true,
							paramVector1, null, true, str2);
			localTableViewDescriptor.setColumnSortOrder(localArrayList);
			paramArrayList.add(localTableViewDescriptor);

			// System.out.println("adding Finish ");

			str1 = getViewResourceEntryKey(resourceName, "ALL_VIEW");
			str2 = getViewResourceEntryKey(resourceName, "ALL_DESC");
			localTableViewDescriptor = TableViewDescriptor
					.newTableViewDescriptor(str1, tableId, true, true,
							paramVector2, null, true, str2);
			localTableViewDescriptor.setColumnSortOrder(localArrayList);
			paramArrayList.add(localTableViewDescriptor);

		} catch (WTPropertyVetoException localWTPropertyVetoException) {
			localWTPropertyVetoException.printStackTrace();
		} catch (WTException exception) {
			// TODO Auto-generated catch block
			exception.printStackTrace();
		}

	}

	/**
	 * @param localVector1
	 * @param localVector2
	 * @param localVector3
	 * @throws WTException
	 */
	private void createColumns(Vector paramVector1, Vector paramVector2,
			Vector paramVector3) throws WTException {
		if (paramVector1.isEmpty()) {
			paramVector1.addAll(getCommonColumnList());
			paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
					"containerName", false));
			paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
					"state", false));
		}

		if (paramVector2.isEmpty()) {

			paramVector2.addAll(getCommonColumnList());
			paramVector2.add(TableColumnDefinition.newTableColumnDefinition(
					"statusFamily_Share", false));
			paramVector2.add(TableColumnDefinition.newTableColumnDefinition(
					"statusFamily_General", false));

			paramVector2.add(TableColumnDefinition.newTableColumnDefinition(
					"statusFamily_Change", false));
			paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
					"containerName", false));
			paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
					"state", false));
		}

		if (paramVector3.isEmpty()) {
			paramVector3.addAll(getCommonColumnList());
		}

	}

	/**
	 * @return
	 */
	@Override
	public String getOOTBActiveViewName() {
		return getViewResourceEntryKey(
				"com.ptc.projectmanagement.plan.planResource", "DEFAULT");
	}

	/**
	 * @return
	 */
	@Override
	public String getDefaultSortColumn() {
		// TODO Auto-generated method stub
		return "name";
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Vector<TableColumnDefinition> getCommonColumnList()
			throws WTException {
		Vector localVector = new Vector();
		localVector.add(TableColumnDefinition.newTableColumnDefinition(
				"type_icon", false));
		localVector.add(TableColumnDefinition.newTableColumnDefinition(
				"infoPageActionAttachment", false));
		localVector.add(TableColumnDefinition.newTableColumnDefinition("name",
				false));

		localVector.add(TableColumnDefinition.newTableColumnDefinition("orgid",
				false));
		localVector.add(TableColumnDefinition.newTableColumnDefinition(
				"infoPageAction", false));

		localVector.add(TableColumnDefinition.newTableColumnDefinition(
				"version", false));
		localVector.add(TableColumnDefinition.newTableColumnDefinition(
				"thePersistInfo.modifyStamp", false));
		return localVector;
	}

	@Override
	public boolean isColumnLocked(String paramString) {
		return ((paramString.equals("type_icon")) || (paramString
				.equals("name")));
	}

	@Override
	public boolean showChooseItemTypesStep() {
		return true;
	}

	@Override
	public boolean showFilteringStep() {
		return false;
	}

	@Override
	public boolean showSortingStep() {
		return false;
	}
}
