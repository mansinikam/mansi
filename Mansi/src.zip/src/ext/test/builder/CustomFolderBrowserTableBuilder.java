
package ext.test.builder;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.CREATED;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.CREATED_BY;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.ICON;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.INFO_ACTION;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.LAST_MODIFIED;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.LOCATION;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NAME;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NON_SELECTABLE_COLUMN;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.STRIKETHROUGH_COLUMN;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.OWNER;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.STATE;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.VERSION;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.core.htmlcomp.components.ConfigurableTableBuilder;
import com.ptc.core.htmlcomp.components.JCAConfigurableTable;
import com.ptc.core.htmlcomp.createtableview.Attribute;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.core.htmlcomp.tableview.SortColumnDescriptor;
import com.ptc.core.htmlcomp.tableview.TableColumnDefinition;
import com.ptc.core.htmlcomp.tableview.TableViewDescriptor;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.FindInTableMode;
import com.ptc.mvc.components.ds.DataSourceMode;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.test.resource.ViewConfigurableTableResource;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@SuppressWarnings("unused")
@ComponentBuilder("ext.test.builder.CustomFolderBrowserTableBuilder")
public class CustomFolderBrowserTableBuilder extends AbstractComponentBuilder implements ConfigurableTableBuilder{

	/**
	 * @param arg0
	 * @param arg1
	 * @return
	 * @throws Exception
	 */
	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams componentParams)
			throws Exception {
		
		NmCommandBean localNmCommandBean = ((JcaComponentParams) componentParams)
				.getHelperBean().getNmCommandBean();
		Folder per = (Folder) localNmCommandBean.getActionOid().getWtRef().getObject();
		System.out.println("Value of per " + per.getClass() );
		return FolderHelper.service.findFolderContents(per);
	}

	/**
	 * @param arg0
	 * @return
	 * @throws WTException
	 */
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0)
			throws WTException {

		ComponentConfigFactory componentConfig = getComponentConfigFactory();
		JcaTableConfig tableConfig = (JcaTableConfig) componentConfig.newTableConfig();
		
		tableConfig.setComponentMode(ComponentMode.VIEW);
		tableConfig.setType("wt.fc.Persistable");
		tableConfig.setLabel("Custom Folder Browser Table");
		tableConfig.setId("ext.test.builder.CustomFolderBrowserTableBuilder");
		tableConfig.setActionModel("part_report_toolbar_actions");
				
		tableConfig.setShowCount(false);
		tableConfig.setSelectable(true);
		tableConfig.setSingleSelect(false);
		
		/*
		 * Alternate method for same purpose.
		 */
		//tableConfig.setFindInTableEnabled(false);
		//tableConfig.setFindInTableMode(FindInTableMode.DISABLED);
		
		tableConfig.setFindInTableMode(FindInTableMode.CLIENT_AND_SERVER);
		//tableConfig.setFindInTableEnabled(true);
		
		ColumnConfig objectIcon = componentConfig.newColumnConfig();
		objectIcon.setLabel("Object Icon");
		objectIcon.setId(ICON);
		objectIcon.setSortable(false);
		objectIcon.setDefaultSort(false);
		tableConfig.addComponent(objectIcon);
		
		ColumnConfig name = componentConfig.newColumnConfig();
		name.setLabel("Name");
		name.setId(NAME);
		name.setSortable(false);
		name.setInfoPageLink(true);
		/*
		 * If you want data store only column then uncomment below line.
		 */
		//name.setDataStoreOnly(true);
		tableConfig.addComponent(name);

		ColumnConfig no = componentConfig.newColumnConfig();
		no.setLabel("Location");
		no.setId(LOCATION);
		no.setSortable(false);
		no.setDefaultSort(false);
		tableConfig.addComponent(no);

		ColumnConfig created = componentConfig.newColumnConfig();
		created.setLabel("Created");
		created.setId(CREATED);
		created.setSortable(false);
		created.setDefaultSort(false);
		
		tableConfig.addComponent(created);

		ColumnConfig state = componentConfig.newColumnConfig();
		state.setLabel(STATE);
		state.setId("State");
		state.setSortable(true);
		state.setDefaultSort(true);
		state.setDefaultSort(false);
		// state.setDataUtilityId("myLifCycleState");
		tableConfig.addComponent(state);

		ColumnConfig lineNumber = componentConfig.newColumnConfig();
		lineNumber.setLabel("Created By");
		lineNumber.setId(CREATED_BY);
		lineNumber.setSortable(false);
		lineNumber.setDefaultSort(false);
		
		tableConfig.addComponent(lineNumber);

		ColumnConfig number = componentConfig.newColumnConfig();
		number.setLabel("Last Modified");
		number.setId(LAST_MODIFIED);
		number.setSortable(false);
		number.setDefaultSort(false);
		tableConfig.addComponent(number);

		ColumnConfig owner = componentConfig
				.newColumnConfig();
		owner.setLabel("Owner");
		owner.setId(OWNER);
		owner.setSortable(false);
		owner.setDefaultSort(false);
		tableConfig.addComponent(owner);
		
		
		ColumnConfig version = componentConfig
				.newColumnConfig();
		version.setLabel("Version");
		version.setId(VERSION);
		version.setSortable(false);
		version.setDefaultSort(false);
		version.setHidden(true);
		tableConfig.addComponent(version);
		
		ColumnConfig infoAction = componentConfig
				.newColumnConfig();
		//infoAction.setLabel("Info Action");
		infoAction.setId(INFO_ACTION);
		//infoAction.setSortable(false);
		//infoAction.setDefaultSort(false);
		tableConfig.addComponent(infoAction);

		
		tableConfig.setDataSourceMode(DataSourceMode.ASYNCHRONOUS);
		//tableConfig.setDataSourceMode(DataSourceMode.SYNCHRONOUS);
		
		ColumnConfig  col1= componentConfig.newColumnConfig ("",  false);
		
		tableConfig.setNonSelectableColumn (col1);
		tableConfig.addComponent(col1);
		
		return tableConfig;
	}

	/**
	 * @param arg0
	 * @return
	 * @throws WTException
	 */
	@Override
	public ConfigurableTable buildConfigurableTable(String arg0)
			throws WTException {
		// TODO Auto-generated method stub
		return new MvcConfigurableTable();
	}
	
	private static class MvcConfigurableTable extends JCAConfigurableTable
    {
		final String resourceName = ViewConfigurableTableResource.class
				.getName();

		/**
		 * @param paramLocale
		 * @return
		 */
		@Override 
		public String getLabel(Locale paramLocale) {
			System.out.println("Getting label ");
			// TODO Auto-generated method stub
			return "Persistable Object Table";
		}

		/**
		 * @param paramLocale
		 * @return
		 */
		@Override
		public List getSpecialTableColumnsAttrDefinition(Locale paramLocale) {
			System.out.println("calling special table column attr definition ::");
			 return Collections.singletonList(new Attribute.TextAttribute("endItem", "End Item", paramLocale));
		}

		/**
		 * @return
		 */
		@Override
		public Class[] getClassTypes() {
			System.out.println("Getting class type :: ");
			return new Class[] { WTPart.class,EPMDocument.class,WTDocument.class };
		}

		/**
		 * @param paramString
		 * @param paramLocale
		 * @return
		 * @throws WTException
		 */
		@Override
		public List getOOTBTableViews(String paramString, Locale paramLocale)
				throws WTException {
			System.out.println("Getting views :: ");
			List localArrayList = new ArrayList();

			Vector localVector1 = new Vector();
			Vector localVector2 = new Vector();
			Vector localVector3 = new Vector();

			createColumns(localVector1, localVector2, localVector3);
			addCommonViews(localArrayList, localVector1, localVector2, localVector3);

			return localArrayList;
		}

		/**
		 * @param paramArrayList
		 * @param paramVector1
		 * @param paramVector2
		 * @param paramVector3
		 */
		private void addCommonViews(List paramArrayList, Vector paramVector1,
				Vector paramVector2, Vector paramVector3) {
			String str1 = "";
			String str2 = "";
			try {
				List localArrayList = new ArrayList();
				SortColumnDescriptor localSortColumnDescriptor = new SortColumnDescriptor();
				localSortColumnDescriptor.setColumnId("name");
				localSortColumnDescriptor.setOrder("ASCENDING");
				localArrayList.add(localSortColumnDescriptor);

				final String tableId = "ext.test.builder.CustomFolderBrowserTableBuilder";
				// TableViewDescriptor localTableViewDescriptor;
				str1 = getViewResourceEntryKey(resourceName, "DEFAULT");
				str2 = getViewResourceEntryKey(resourceName, "DEFAULT_DESC");
				TableViewDescriptor localTableViewDescriptor = TableViewDescriptor
						.newTableViewDescriptor(str1, tableId, true, true,
								paramVector3, null, true, str2);
				localTableViewDescriptor.setColumnSortOrder(localArrayList);
				paramArrayList.add(localTableViewDescriptor);

				str1 = getViewResourceEntryKey(resourceName, "STATE");
				str2 = getViewResourceEntryKey(resourceName, "STATE_DESC");
				localTableViewDescriptor = TableViewDescriptor
						.newTableViewDescriptor(str1, tableId, true, true,
								paramVector1, null, true, str2);
				localTableViewDescriptor.setColumnSortOrder(localArrayList);
				paramArrayList.add(localTableViewDescriptor);

				// System.out.println("adding Finish ");

				str1 = getViewResourceEntryKey(resourceName, "ALL_VIEW");
				str2 = getViewResourceEntryKey(resourceName, "ALL_DESC");
				localTableViewDescriptor = TableViewDescriptor
						.newTableViewDescriptor(str1, tableId, true, true,
								paramVector2, null, true, str2);
				localTableViewDescriptor.setColumnSortOrder(localArrayList);
				paramArrayList.add(localTableViewDescriptor);

			} catch (WTPropertyVetoException localWTPropertyVetoException) {
				localWTPropertyVetoException.printStackTrace();
			} catch (WTException exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}

		}

		/**
		 * @param localVector1
		 * @param localVector2
		 * @param localVector3
		 * @throws WTException
		 */
		private void createColumns(Vector paramVector1, Vector paramVector2,
				Vector paramVector3) throws WTException {
			if (paramVector1.isEmpty()) {
				paramVector1.addAll(getCommonColumnList());
				paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
						CREATED, false));
				paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
						STATE, false));
			}

			if (paramVector2.isEmpty()) {

				paramVector2.addAll(getCommonColumnList());
				paramVector2.add(TableColumnDefinition.newTableColumnDefinition(
						CREATED, false));
				paramVector2.add(TableColumnDefinition.newTableColumnDefinition(
						STATE, false));

				paramVector2.add(TableColumnDefinition.newTableColumnDefinition(
						CREATED_BY, false));
				paramVector1.add(TableColumnDefinition.newTableColumnDefinition(
						OWNER, false));
			}

			if (paramVector3.isEmpty()) {
				paramVector3.addAll(getCommonColumnList());
			}

		}

		/**
		 * @return
		 */
		@Override
		public String getOOTBActiveViewName() {
			System.out.println("Getting active view name");
			return getViewResourceEntryKey(
					resourceName, "DEFAULT");
		}

		/**
		 * @return
		 */
		@Override
		public String getDefaultSortColumn() {
			System.out.println("Getting default sort column :: ");
			// TODO Auto-generated method stub
			return LAST_MODIFIED;
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		private Vector<TableColumnDefinition> getCommonColumnList()
				throws WTException {
			Vector localVector = new Vector();
			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					ICON, false));
			
			localVector.add(TableColumnDefinition.newTableColumnDefinition(NAME,
					false));

			
			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					INFO_ACTION, false));

			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					VERSION, false));
			localVector.add(TableColumnDefinition.newTableColumnDefinition(
					LAST_MODIFIED, false));
			return localVector;
		}

		@Override
		public boolean isColumnLocked(String paramString) {
			System.out.println("Geting locked column name ::");
			return ((paramString.equals("type_icon")) || (paramString
					.equals("name")));
		}

		@Override
		public boolean showChooseItemTypesStep() {
			System.out.println("Getting choose item type step ::");
			return true;
		}

		@Override
		public boolean showFilteringStep() {
			System.out.println("Getting choose filtering step ::");
			return true;
		}

		@Override
		public boolean showSortingStep() {
			System.out.println("Getting choose sorting step :: ");
			return true;
		}
    }
}
