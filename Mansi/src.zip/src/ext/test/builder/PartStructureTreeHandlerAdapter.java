package ext.test.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;

import com.ptc.core.components.beans.TreeHandlerAdapter;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.product.commands.EndItemsCommand;


/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
public class PartStructureTreeHandlerAdapter extends TreeHandlerAdapter {

	/**
	 * Private variable for Logger.
	 */
	private static final org.apache.log4j.Logger LOG = LogR
			.getLogger(PartStructureTreeHandlerAdapter.class
					.getName());
	
	/**
	 * @param paramList
	 * @return
	 * @throws WTException
	 */
	@Override
	public Map<Object, List> getNodes(List paramList) throws WTException {
		final Map<Object, List> nodes = new HashMap<Object, List>();
		List list = new ArrayList();
		Persistable per;
		System.out.println("List size : " + paramList.size());
		/*
		 * Fetching child of the given parent.
		 */
		for (ListIterator localListIterator = paramList.listIterator(); localListIterator
				.hasNext(); nodes.put(per, list)) {
			//System.out.println("The value is : " + localListIterator);
			per = (Persistable) localListIterator.next();
			//System.out.println("The :: " + per);
			//System.out.println(per.getClass() + " :: Name of the class ");
			list = (getImmediateChildren(per));
			//System.out.println(" The value of the list :: " + list);
		}
		
		System.out.println("Final Value of Nodes : " + nodes);
		
		return nodes;
	}

	/**
	 * @param per
	 * @return
	 */
	private List getImmediateChildren(Persistable per) {
		List<Persistable> persist = new ArrayList<Persistable>();
		if(per instanceof WTPart){
			QueryResult queryResult = null;
			try {
				queryResult = WTPartHelper.service.getUsesWTParts((WTPart) per, new LatestConfigSpec());
			} catch (WTException exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}
	        while(queryResult!=null && queryResult.hasMoreElements())
	        {
	                        WTPart part=null;
	                        Persistable[] persistable=(Persistable[])queryResult.nextElement();
	                        part=(WTPart)persistable[1];
	                        persist.add(part);
	        }
		}
		System.out.println("List of Persistable : " + persist);
		return persist;
	}

	/**
	 * @return
	 * @throws WTException
	 */
	@Override
	public List<Object> getRootNodes() throws WTException {
		final List<Object> rootNodes = new ArrayList<Object>();
		final NmCommandBean localNmCommandBean = getModelContext()
				.getNmCommandBean();
		LOG.debug("Inside get root nodes ::");
		System.out.println("Inside get root nodes ::");
		if (localNmCommandBean != null) {
			QueryResult result = new QueryResult();
			try {
				result = EndItemsCommand.getEndItems(localNmCommandBean);
			} catch (Exception exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}
			rootNodes.add(result.nextElement());
		}
		System.out.println("Root nodes are : " + rootNodes);
		return rootNodes;
	}

	

}
