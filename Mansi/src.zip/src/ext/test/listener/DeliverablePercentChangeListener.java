package ext.test.listener;

import wt.util.WTException;

/**
 * Interface used for listener.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 * 
 */
public interface DeliverablePercentChangeListener {

	/**
	 * This method will be over ride in the Service.
	 * 
	 * @param event
	 *            the event for which the listener will be invoke
	 * 
	 * @exception WTException
	 *                throws {@link WTException}
	 * 
	 */
	void listenForPercentChange(Object event) throws WTException;
}

