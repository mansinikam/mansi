package ext.test.validator;

import java.util.Locale;

import org.apache.log4j.Logger;

import wt.util.WTException;

import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationFeedbackMsg;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;

//ext.test.validator.SamplePromptValidator
/**
 * Validator for confirmation prompt.
 * 
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
public class SamplePromptValidator extends DefaultUIComponentValidator {

	/**
	 * Private variable for {@link Logger}.
	 */
	private static final Logger LOG = wt.log4j.LogR.getLogger(SamplePromptValidator.class.getName());


	
	/**
	 * @param validationKey
	 * @param criteria
	 * @param aLocale
	 * @return
	 * @throws WTException
	 */
	@Override
	public UIValidationResultSet validateSelectedMultiSelectAction(UIValidationKey validationKey, UIValidationCriteria criteria,
			Locale aLocale) throws WTException {
		// TODO Auto-generated method stub
		
		System.out.println("Inside validate selected multi action");
		
		UIValidationResultSet resultset = UIValidationResultSet.newInstance();
		
		
		/*
		 * Reading the confirmation message from Resource Bundle.
		 */
		final String confirmationMsg = "Do you want to proceed with the operation ?";
		System.out.println("The confirmation message :: " + confirmationMsg);
		/*
		 * Creating UIValidationFeedbackMsg.
		 */
		final UIValidationFeedbackMsg message = UIValidationFeedbackMsg
				.newInstance(confirmationMsg, FeedbackType.CONFIRMATION);

		UIValidationResult result = (UIValidationResult.newInstance(validationKey,
				UIValidationStatus.PROMPT_FOR_CONFIRMATION, message));
		
		resultset.addResult(result);
		
		return resultset;
	}
	
	/**
	 * @param validationKey
	 * @param validationCriteria
	 * @param aLocale
	 * @return
	 * @throws WTException
	 */
	@Override
	public UIValidationResult validateSelectedAction(UIValidationKey validationKey, UIValidationCriteria validationCriteria
			, Locale aLocale)
			throws WTException {
		// TODO Auto-generated method stub
		System.out.println("Inside validate selected action");
		
		/*
		 * Creating the result set object.
		 */
		System.out.println("inside validator ::");

		/*
		 * Reading the confirmation message from Resource Bundle.
		 */
		final String confirmationMsg = "Do you want to proceed with the operation ?";
		System.out.println("The confirmation message :: " + confirmationMsg);
		/*
		 * Creating UIValidationFeedbackMsg.
		 */
		final UIValidationFeedbackMsg message = UIValidationFeedbackMsg
				.newInstance(confirmationMsg, FeedbackType.CONFIRMATION);

		UIValidationResult result = (UIValidationResult.newInstance(validationKey,
				UIValidationStatus.PROMPT_FOR_CONFIRMATION, message));

		
		
		
		return result;
	}
	
	
}