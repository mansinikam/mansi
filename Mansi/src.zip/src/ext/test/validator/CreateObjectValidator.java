package ext.test.validator;

import java.util.Locale;

import wt.inf.container.WTContainerRef;
import wt.pdmlink.PDMLinkProduct;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;

/**
 * Validator to validate an action. Only enable the action in PDMLinkProduct.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 */
public class CreateObjectValidator extends DefaultUIComponentValidator {
	/**
	 * Overidden method of "DefaultUIComponentValidator".
	 * 
	 * @param validationKey
	 *            The String identifying the action or component being
	 *            validated.
	 * @param validationCriteria
	 *            Object holding information required to per form validation
	 *            tasks.
	 * @param locale
	 *            The user's Locale. If a null value is passed in, the session
	 *            locale will be used.
	 * @return UIValidationResultSet
	 */
	@SuppressWarnings("rawtypes")
	public UIValidationResultSet performFullPreValidation(
			UIValidationKey validationKey,
			UIValidationCriteria validationCriteria, Locale locale) {
		// Creates UIValidationResultSet
		UIValidationResultSet resultSet = UIValidationResultSet.newInstance();
		/*
		 * Fetching the container reference from which this validator is called
		 * now.
		 */
		WTContainerRef localWTContainerRef = validationCriteria
				.getParentContainer();
		Class localClass = localWTContainerRef.getReferencedClass();
		boolean bool1 = PDMLinkProduct.class.isAssignableFrom(localClass);
		/*
		 * If the validator is called from PDMLinkProduct enable the action else
		 * hide it.
		 */
		if (bool1) {
			resultSet.addResult(UIValidationResult.newInstance(validationKey,
					UIValidationStatus.ENABLED));
		} else {
			resultSet.addResult(UIValidationResult.newInstance(validationKey,
					UIValidationStatus.HIDDEN));
		}
		return resultSet;
	}
}
