/**
 * 
 */
package ext.test.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@RBUUID("ext.test.resource.ViewConfigurableTableResource")
public class ViewConfigurableTableResource extends WTListResourceBundle {

	/**
	 * Label for custom view.
	 */
	@RBEntry("All")
	public static final String ALL = "ALL_VIEW";

	/**
	 * Label for custom view.
	 */
	@RBEntry("All View")
	public static final String ALL_DESC = "ALL_DESC";

	/**
	 * Label for custom view.
	 */
	@RBEntry("State")
	public static final String STATE = "STATE";

	/**
	 * Label for custom view.
	 */
	@RBEntry("State View")
	public static final String STATE_DESC = "STATE_DESC";
	
	/**
	 * Label for custom view.
	 */
	@RBEntry("Default")
	public static final String DEFAULT = "DEFAULT";

	/**
	 * Label for custom view.
	 */
	@RBEntry("Default View")
	public static final String DEFAULT_DESC = "DEFAULT_DESC";

	
}
