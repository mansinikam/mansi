/**
 * Custom class file.
 * 
 * @author 'true' 12805
 * 
 * @version 'true' 1.0
 *
 */
package ext;

import wt.doc.WTDocument;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.value.litevalue.FloatValueDefaultView;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;

/**
 * @author 12805
 *
 */
public class AdvancedWTPartQuerySpec implements RemoteAccess {
	
	public static final String PARTSUBTYPE = "wt.doc.WTDocument";
	
	public static final String STATE = "Obsolete";

	public static void main(String[] args) throws WTPropertyVetoException, WTException {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");

		/*
		 * try { rms.invoke("readReleasedDateValue",
		 * AdvancedQuerySpecTest.class.getName(), null, new Class[] {}, new
		 * Object[] {}); } catch (RemoteException | InvocationTargetException e)
		 * { // TODO Auto-generated catch block e.printStackTrace(); }
		 */

		readReleasedDateValue();
	}

	/**
	 * 
	 */
	private static void readReleasedDateValue() throws WTException {
		boolean flagAccess = SessionServerHelper.manager.isAccessEnforced();
		SessionServerHelper.manager.setAccessEnforced(false);

		QuerySpec subSelect = new QuerySpec();

		int bwtPart = subSelect.appendClassList(WTPart.class, false);
		int bwtPartMaster = subSelect.appendClassList(WTPartMaster.class, false);
		//int bwtTypeDef = subSelect.appendClassList(WTTypeDefinition.class, false);

		ClassAttribute subBranchIditerationInfo = new ClassAttribute(WTPart.class, "iterationInfo.branchId");
		SQLFunction maxFunction = SQLFunction.newSQLFunction(SQLFunction.MAXIMUM, subBranchIditerationInfo);
		subSelect.appendSelect(maxFunction, new int[] { bwtPart }, false);
		subSelect.appendWhere(new SearchCondition(WTPart.class, "masterReference.key.id", WTPartMaster.class,
				"thePersistInfo.theObjectIdentifier.id"), new int[] { bwtPart, bwtPartMaster });
		subSelect.appendGroupBy(new ClassAttribute(WTPartMaster.class, WTPartMaster.NUMBER),
				new int[] { bwtPartMaster }, false);
		subSelect.setAdvancedQueryEnabled(true);

		QuerySpec mainSpec = new QuerySpec();

		int wtpartMain = mainSpec.addClassList(WTPart.class, true);
	
		int typeIndex = mainSpec.appendClassList(WTTypeDefinition.class, false);

		mainSpec.appendWhere(new SearchCondition(WTPart.class, WTPart.LIFE_CYCLE_STATE, SearchCondition.NOT_EQUAL,
				STATE), new int[] { wtpartMain });
		mainSpec.appendAnd();

		final SearchCondition sctype = new SearchCondition(WTPart.class, "typeDefinitionReference.key.id",
				WTTypeDefinition.class, "thePersistInfo.theObjectIdentifier.id");

		mainSpec.appendWhere(sctype, new int[] { wtpartMain, typeIndex });
		mainSpec.appendAnd();

		mainSpec.appendWhere(
				new SearchCondition(WTDocument.class, WTDocument.LATEST_ITERATION, SearchCondition.IS_TRUE),
				new int[] { wtpartMain });
		mainSpec.appendAnd();

		SearchCondition scSWPart = new SearchCondition(WTTypeDefinition.class, "logicalIdentifier",
				SearchCondition.LIKE, "%" + PARTSUBTYPE + "%", true);
		mainSpec.appendWhere(scSWPart, new int[] { typeIndex });
		mainSpec.appendAnd();

		mainSpec.appendWhere(new SearchCondition(subBranchIditerationInfo, SearchCondition.IN, new SubSelectExpression(
				subSelect)), new int[] { wtpartMain });
		mainSpec.setAdvancedQueryEnabled(true);

		final QueryResult result = PersistenceServerHelper.manager.query(mainSpec);

		System.out.println("Result Size : " + result.size());
		//new FloatValueDefaultView(paramFloatDefView, paramDouble, paramInt)
		while (result.hasMoreElements()) {

			Object[] objs = (Object[]) result.nextElement();

			WTPart partMain = (WTPart) objs[wtpartMain];
			System.out.println("-------------------------------------- Part details ---------------------------------------");
			System.out.println(partMain.getNumber());
			System.out.println(partMain.getName());
			String str1 = partMain.getVersionInfo().getIdentifier().getValue();//for revision 
			String str2 = partMain.getIterationIdentifier().getValue();//for iteration

			System.out.println("Revision : " + str1);
			System.out.println("Iteration : " + str2);
		}

		SessionServerHelper.manager.setAccessEnforced(flagAccess);

	}

}
