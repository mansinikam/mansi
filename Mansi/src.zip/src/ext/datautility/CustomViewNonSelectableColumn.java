package ext.datautility;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AbstractBooleanValueDataUtility;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
public class CustomViewNonSelectableColumn extends AbstractBooleanValueDataUtility {

	/**
	 * @param paramString
	 * @param paramObject
	 * @param paramModelContext
	 * @return
	 * @throws WTException
	 */
	@Override
	public boolean getBooleanAttributeValue(String paramString,
			Object paramObject, ModelContext paramModelContext)
			throws WTException {
		
		boolean valueToReturn = false;
		System.out.println(paramObject.getClass() + " Inside custom data utility ");
		String ViewName =  (String) paramModelContext.getDefaultValue();
		
		if (ViewName.equalsIgnoreCase("Manufacturing")) {
			valueToReturn = true;
		}
		return Boolean.valueOf(valueToReturn);
	}

}
