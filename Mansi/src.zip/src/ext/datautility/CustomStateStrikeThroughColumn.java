/**
 * 
 */
package ext.datautility;

import java.util.Locale;

import wt.lifecycle.LifeCycleState;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
// ext.datautility.CustomStateStrikeThroughColumn
public class CustomStateStrikeThroughColumn extends AbstractDataUtility {

	/**
	 * @param componentId
	 * @param datum
	 * @param modelContext
	 * @return
	 * @throws WTException
	 */
	@Override
	public Object getDataValue(String componentId, Object datum,
			ModelContext modelContext) throws WTException {
		boolean valueToReturn = false;
		System.out.println(datum.getClass() + " Inside custom data utility ");
		LifeCycleState state = (LifeCycleState) modelContext.getDefaultValue();
		String stateValue = state.getState().getDisplay(Locale.US);
		if (stateValue.equalsIgnoreCase("Released")) {
			valueToReturn = true;
		}
		return Boolean.valueOf(valueToReturn);
	}

	/*
	 * Alternatively you can extend
	 * com.ptc.core.components.factory.dataUtilities.AbstractBooleanValueDataUtility
	 *  and implement below method which returns
	 * boolean value.
	 * 
	 * @Override public boolean getBooleanAttributeValue(String arg0, Object
	 * arg1, ModelContext arg2) throws WTException { // TODO Auto-generated
	 * method stub return false; }
	 */

}
