package ext.datautility;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionReference;
import wt.vc.config.LatestConfigSpec;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.guicomponents.IconComponent;

import ext.tablebuilder.MyReportBean;

public class LifeCycleDataUtility extends AbstractDataUtility {
		@Override
		public Object getDataValue(String component_id, Object datum, ModelContext mc) throws WTException 
		{
			MyReportBean bean  = (MyReportBean)datum;
			//bean.getState();
			WTPart part = null;
			String imgURL = null;
			QuerySpec spec = new QuerySpec(WTPart.class);
			spec.appendWhere(new SearchCondition(WTPart.class,WTPart.NUMBER,SearchCondition.EQUAL,bean.getNo()),new int[]{ 0 });
			LatestConfigSpec latestCSpec = new LatestConfigSpec();
			spec = latestCSpec.appendSearchCriteria(spec);
			QueryResult qr =  PersistenceHelper.manager.find((StatementSpec)spec);
			while(qr.hasMoreElements())
			{
				part = (WTPart)qr.nextElement();
			}
			String state = part.getState().getState().toString();
			if ( state.equals("RELEASED") ) { imgURL = "netmarkets/images/green.gif"; }
			else if ( state.equals("INWORK") ) { imgURL = "netmarkets/images/yellow.gif"; }
			else { imgURL = "netmarkets/images/red.gif"; }
			IconComponent iconComponent = new IconComponent(imgURL);
			iconComponent.setUrl("app/#ptc1/tcomp/infoPage?ContainerOid=OR:" + part.getContainerReference() +"&oid=" + "VR:" + 
					VersionReference.newVersionReference(part).toString().replaceAll(">", ":"));
			return iconComponent;
		}
}

/*
 * The above Datautility will replace the State name by an Image and it�s also
 * hyper linked to the corresponding WTPart�s information page. Register this
 * data utility in site.xconf as selector �myLifCycleState�. Mention the same
 * name as datautilityid inside the buildComponentConfig method.
 */
