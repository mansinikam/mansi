package ext.datautility;

import java.util.ArrayList;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.core.components.rendering.guicomponents.Label;

import ext.tablebuilder.MyReportBean;

public class CustomNameDataUttility extends AbstractDataUtility {
	
		@Override
		public Object getDataValue(String componentid, Object datum, ModelContext mc) throws WTException 
		{
			MyReportBean bean  = (MyReportBean)datum;
			WTPart part = null;
			String imgUrlPart = null;
			String dots = "";
			for(int i =0;i<Integer.parseInt(bean.getLevel())*2;i++)
				dots+="..";
			QuerySpec spec = new QuerySpec(WTPart.class);
			spec.appendWhere(new SearchCondition(WTPart.class,WTPart.NUMBER,SearchCondition.EQUAL,bean.getNo()),new int[]{ 0 });
			LatestConfigSpec latestCSpec = new LatestConfigSpec();
			spec = latestCSpec.appendSearchCriteria(spec);
			QueryResult qr =  PersistenceHelper.manager.find((StatementSpec)spec);
			while(qr.hasMoreElements())
			{
				part = (WTPart)qr.nextElement();
			}
			
			if(part.isEndItem())
				imgUrlPart="netmarkets/images/config_part_enditem.gif";
			else
				imgUrlPart="netmarkets/images/part.gif";
			ArrayList<GuiComponent> list = new ArrayList<GuiComponent>();
			list.add(new Label(dots));
			list.add(new IconComponent(imgUrlPart));
			list.add(new Label(part.getName()));
			return new GUIComponentArray(list);
		}
		
		/*public ColumnDescriptor getColumnDescriptor(String paramString, ModelContext paramModelContext)
	       {
		      ColumnDescriptor localColumnDescriptor = ColumnDescriptorFactory.getInstance().newDefaultColumn(paramModelContext.getDescriptor());
		      localColumnDescriptor.setWidth(175);
		      localColumnDescriptor.setResizable(true);
		     return localColumnDescriptor;
	      }*/
}

